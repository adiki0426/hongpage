package dto;

public class UserDTO {

	private String id;
	private String psw;
	private String name;
	private String ts;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPsw() {
		return psw;
	}
	public void setPsw(String psw) {
		this.psw = psw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTs() {
		return ts;
	}
	public void setTs(String ts) {
		this.ts = ts;
	}
	

	@Override
	public String toString() {
		return "UserDTO [id=" + id + ", psw=" + psw + ", name=" + name + ", ts=" + ts + "]";
	}
	
	
}

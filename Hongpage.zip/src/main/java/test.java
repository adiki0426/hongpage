
public class test {
	public static void main(String[] args) {

		String id = "admin_id";

		if (!id.equals("hong")) {
			System.out.println("1번");
			if (!id.equals("admin_id")) {
				System.out.println("2번");
				
			}
		}

		System.out.println("if문 탈출");
	}
}

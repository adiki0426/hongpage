package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.BreakIterator;

import javax.naming.NamingException;

import dto.UserDTO;

/**
 * 데이터베이스의 member talble을 관리하는 객체 - DB 접속 member table select insert update
 * delete CRUD
 */

public class UserDAO {
	// 이미 가입한 회원
	// 회원 가입 성공하면 true를 리턴하도록 함수를 작성

	// 내가 수정한 것 ---------------------------------------
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver"; // jdbc 드라이버 주소
	static final String DB_URL = "jdbc:mysql://localhost:3306/hongpage?useSSL=false"; // DB 접속 주소
	// localhost는 접속하려는 데이터베이스 주소를 입력하시면 됩니다. localhost를 사용하면 됩니다.
	// databasename에는 접속하려는 database의 name을 입력해줍니다.
	static final String USERNAME = "root"; // DB ID
	static final String PASSWORD = "admin1234"; // DB Password

	// MySql에 사용하는여러 객체를 만들어줍니다.

	public UserDAO() {
		Connection conn = null;
		try {
			// 드라이버 로드
			Class.forName(JDBC_DRIVER);
			// Db 연결
			conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
			
			System.out.println("conn : " + conn);
			System.out.println("드라이버 로딩 성공");

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 실패");
			try {
				conn.close();
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}

	}

	public int login(String uid, String upsw) throws SQLException {
		String sql = "SELECT * FROM USER WHERE id = ?";
		Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, uid);
		ResultSet rs = pstmt.executeQuery();
		try {
			if (!rs.next())
				return 1;
			if (!rs.getString("password").equals(upsw))

				return 2;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return 3; // 정상 처리
	}
	// -------------------------------------------------------------
// 회원가입
	public boolean insert(String uid, String upsw, String uname) throws SQLException {
		// DB의 접속 객체 가져와서 사용 -
		String sql = "insert into user(id,password,name,ts) values(?,?,?,now())"; // stmt를통해 바인딩
		Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
		try (PreparedStatement pstmt = conn.prepareStatement(sql);) {
			pstmt.setString(1, uid);
			pstmt.setString(2, upsw);
			pstmt.setString(3, uname);

			int count = pstmt.executeUpdate();
			return count == 1;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
// -----------------------------------------------------
//	 회원 존재여부를 체크하는 함수
//	 회원 uid를 member테이블에서 조회해서 있으면 true 없으면 false
//	 resultset 객체로 결과를 받아들임
//	 executeQuery()
	public boolean exists(String uid) throws SQLException {

		ResultSet rs = null;
		String sql = "select * from user where id = ?";
		Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
		try (PreparedStatement pstmt = conn.prepareStatement(sql);) {
			pstmt.setString(1, uid);
			rs = pstmt.executeQuery();
			return rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return false;
	}
	public boolean find(String uid, String uname) throws SQLException {
		ResultSet rs = null;
		String sql = "SELECT password FROM USER WHERE (id = ?) and (name = ?)";
		try {
			Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, uid);
			pstmt.setString(2, uname);
			rs = pstmt.executeQuery();
			return rs.next();
		} catch (Exception e) {
			// TODO: handle exception
		} return false;				
	}
	
	
	
	
	public String find_str(String uid, String uname) throws SQLException {
		ResultSet rs = null;
		String sql = "SELECT password FROM USER WHERE (id = ?) and (name = ?)";
		
			Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, uid);
			pstmt.setString(2, uname);
			rs = pstmt.executeQuery();
			rs.next();
			return rs.getString("password");
}
	
//
//	public int exists(String uid, String upsw) {
//		ResultSet rs = null;
//		String sql = "SELECT * FROM USER WHERE id = ?";
//		try {
//			PreparedStatement pstmt = conn.prepareStatement(sql);
//			pstmt.setString(1, uid);
//			rs = pstmt.executeQuery();
//			if (!rs.next())
//				return 1;
//			if (!rs.getString("upsw").equals(upsw))
//				return 2;
//		} catch (Exception e) {
//			e.printStackTrace();
//			return 0;
//		} finally {
//			try {
//				if (rs != null)
//					rs.close();
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//		}
//		return 3; // 정상 처리
//	}

//	// delete from member where uid = ?
//	// executeUpdate
//	public boolean delete(String uid) {
//		String sql = "delete from user where id = ?";
//		try (Connection conn = ConnectionPool.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
//			pstmt.setString(1, uid);
//			int count = pstmt.executeUpdate();
//			return count == 1;
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return false;
//	}
//
}

package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;

import dto.BbsDTO;

public class Test {
	private Connection conn;
	private ResultSet rs;

	public Test() {
		try {
			String DB_URL = "jdbc:mysql://localhost:3306/hongpage?useSSL=false"; // DB 접속 주소
			String USERNAME = "root"; // DB ID
			String PASSWORD = "admin1234"; // DB Password
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
			System.out.println("conn : " + conn);
			System.out.println("드라이버 로딩 성공");

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 실패");
		}
	}

	public int getNext() { // 다음 글 가지고 오기
		String sql = "SELECT bbsID FROM BBS ORDER BY BBSID DESC";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getInt(1) + 1;
			}
			return 1; // 첫 번째 게시물인 경우
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; // 데이터 베이스 오류
	}

	public ArrayList<BbsDTO> getList(int pageNumber) {
		String sql = "SELECT * FROM bbs join bbs_game_opti WHERE bbsID < ? AND bbsAvailable = 1 ORDER BY bbsID DESC LIMIT 10";
		ArrayList<BbsDTO> list = new ArrayList<BbsDTO>();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				BbsDTO bbs = new BbsDTO();
				bbs.setBbsID(rs.getInt(1));
				bbs.setBbsTitle(rs.getString(2));
				bbs.setUserID(rs.getString(3));
				bbs.setBbsDate(rs.getString(4));
				bbs.setBbsContent(rs.getString(5));
				bbs.setBbsAvailable(rs.getInt(6));
				list.add(bbs);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public static void main(String[] args) {
		Test test = new Test();
		ArrayList<BbsDTO> list = test.getList(0);
		for (int i= 0; i<list.size(); i++) {
			System.out.print("["+list.get(i).getBbsID()+"] ");
			System.out.print("["+list.get(i).getBbsTitle()+"] ");
			System.out.print("["+list.get(i).getUserID()+"]");
			System.out.println();
			
		}
		
	}
}

package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.catalina.Context;

//public class ConnectionPool {
//	private static DataSource _ds = null;
//
//	public static Connection getConnection() throws NamingException, SQLException {
//		if (_ds == null)
////			_ds = (DataSource) (new InitialContext()).lookup("java:comp/env/jdbc/myfeed");
//			_ds = (DataSource) (new InitialContext()).lookup("java:comp/env/jdbc/hongpage");
//		return _ds.getConnection();
//	}
//
//	public static void main(String[] args) {
//		System.out.println(_ds);
//	}
//}
//		final String JDBC_DRIVER = "org.h2.Driver";
//		final String JDBC_URL = "jdbc:h2:tcp://localhost/~/test";
//		final String ID = "sa";
//		final String PSW = "admin1234";
//		// DB 연결	
//		Connection conn = null;
//		try {			
//			Class.forName(JDBC_DRIVER); // 드라이버 로드			
//			conn = DriverManager.getConnection(JDBC_URL, ID, PSW); // Db 연결
//		} catch (Exception e) {
//			e.printStackTrace();
//		}		
//		return conn;

public class ConnectionPool {
	static Connection conn;
	static Connection getConnection() throws NamingException, SQLException {
		final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver"; // jdbc 드라이버 주소
		final String DB_URL = "jdbc:mysql://localhost:3306/hongpage?useSSL=false"; // DB 접속 주소
		// localhost는 접속하려는 데이터베이스 주소를 입력하시면 됩니다. localhost를 사용하면 됩니다.
		// databasename에는 접속하려는 database의 name을 입력해줍니다.
		final String USERNAME = "root"; // DB ID final
		String PASSWORD = "admin1234"; // DB Password

		// DB 연결 Connection conn = null; try { Class.forName(JDBC_DRIVER); // 드라이버 로드
		try {
			conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
			return conn;
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // DB연결
		return conn;
		
	
	}
	public static void main(String[] args) {
		System.out.println(conn);
	}
}
